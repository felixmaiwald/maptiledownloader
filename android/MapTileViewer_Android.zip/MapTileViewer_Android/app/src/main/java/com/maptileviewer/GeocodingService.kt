package com.maptileviewer

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.osmdroid.util.GeoPoint

/**
 * Wrapper fuer die Nominatim-Geocoding-API von OpenStreetMap.
 *
 * Alle Netzwerkaufrufe laufen via Kotlin Coroutines im IO-Dispatcher.
 * Der User-Agent ist gemaess Nominatim-Nutzungsrichtlinien gesetzt.
 */
object GeocodingService {

    private val client = OkHttpClient()

    /**
     * Sucht einen Ortsnamen und gibt den ersten Treffer als GeoPoint zurueck.
     *
     * @param query  Freitext-Suchanfrage (z. B. "Marienplatz München")
     * @return       GeoPoint des ersten Treffers, oder null bei Fehler / kein Ergebnis
     */
    suspend fun search(query: String): GeoPoint? = withContext(Dispatchers.IO) {
        try {
            val url = "https://nominatim.openstreetmap.org/search" +
                      "?q=${query.trim().replace(" ", "+")}&format=json&limit=1"
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "MapTileViewer/1.0 (Android; personal use)")
                .build()
            val body = client.newCall(req).execute().use { it.body?.string() }
            val arr  = JSONArray(body ?: return@withContext null)
            if (arr.length() == 0) return@withContext null
            val obj  = arr.getJSONObject(0)
            GeoPoint(obj.getDouble("lat"), obj.getDouble("lon"))
        } catch (e: Exception) {
            null
        }
    }
}
