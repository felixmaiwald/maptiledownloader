package com.maptileviewer

import android.graphics.*
import android.view.MotionEvent
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.*

/**
 * Canvas-Overlay fuer das Messwerkzeug.
 *
 * Ermoeglicht es, durch Tippen auf die Karte eine Polylinie aufzubauen
 * und die Gesamtlaenge sowie jede Segmentlaenge anzuzeigen.
 *
 * Distanzberechnung: Haversine-Formel (Fehler < 0,5 %).
 *
 * @param onDistanceChanged  Callback, wird nach jedem Tap mit der neuen
 *                           Gesamtdistanz (Meter) aufgerufen.
 */
class MeasureOverlay(
    private val onDistanceChanged: (totalMeters: Double, pointCount: Int) -> Unit
) : Overlay() {

    var isActive: Boolean = false
    private val points = mutableListOf<GeoPoint>()

    // ── Paint-Objekte (einmalig alloziert) ────────────────────────────────────

    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.parseColor("#FFDD00")
        strokeWidth = 4f
        style  = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(20f, 10f), 0f)
    }
    private val lineShadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color  = Color.parseColor("#99000000")
        strokeWidth = 7f
        style  = Paint.Style.STROKE
    }
    private val dotPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF3333")
        style = Paint.Style.FILL
    }
    private val dotBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeWidth = 3f
        style = Paint.Style.STROKE
    }
    private val labelBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#CC000000")
        style = Paint.Style.FILL
    }
    private val labelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.parseColor("#FFEE44")
        textSize  = 32f
        typeface  = Typeface.DEFAULT_BOLD
    }
    private val pointLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color    = Color.WHITE
        textSize = 30f
        typeface = Typeface.DEFAULT_BOLD
    }

    // ── Overlay-Zeichnung ─────────────────────────────────────────────────────

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow || points.isEmpty()) return

        val proj     = mapView.projection
        val screenPts = points.map { proj.toPixels(it, null) }

        // Verbindungslinien
        for (i in 1 until screenPts.size) {
            val p0 = screenPts[i - 1]
            val p1 = screenPts[i]
            canvas.drawLine(p0.x.toFloat(), p0.y.toFloat(),
                            p1.x.toFloat(), p1.y.toFloat(), lineShadow)
            canvas.drawLine(p0.x.toFloat(), p0.y.toFloat(),
                            p1.x.toFloat(), p1.y.toFloat(), linePaint)

            // Segment-Distanz in der Mitte
            val dist  = haversine(points[i - 1], points[i])
            val label = formatDistance(dist)
            val mx    = ((p0.x + p1.x) / 2).toFloat()
            val my    = ((p0.y + p1.y) / 2).toFloat()
            drawLabelWithBg(canvas, label, mx, my, labelPaint, labelBg)
        }

        // Punkte + Buchstaben-Labels
        val alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        screenPts.forEachIndexed { i, pt ->
            val cx = pt.x.toFloat()
            val cy = pt.y.toFloat()
            canvas.drawCircle(cx, cy, 16f, dotPaint)
            canvas.drawCircle(cx, cy, 16f, dotBorder)
            val lbl = if (i < alphabet.length) alphabet[i].toString() else "${i + 1}"
            drawLabelWithBg(canvas, lbl, cx, cy - 26f, pointLabelPaint, labelBg)
        }
    }

    /**
     * Zeichnet einen Text mit dunklem Hintergrund-Rechteck fuer Lesbarkeit.
     */
    private fun drawLabelWithBg(
        canvas: Canvas, text: String,
        x: Float, y: Float,
        paint: Paint, bgPaint: Paint
    ) {
        val bounds = Rect()
        paint.getTextBounds(text, 0, text.length, bounds)
        val pad = 6f
        canvas.drawRoundRect(
            x - bounds.width() / 2f - pad, y - bounds.height() - pad,
            x + bounds.width() / 2f + pad, y + pad,
            6f, 6f, bgPaint
        )
        canvas.drawText(text, x - bounds.width() / 2f, y, paint)
    }

    // ── Touch-Handling ─────────────────────────────────────────────────────────

    override fun onSingleTapConfirmed(e: MotionEvent, mapView: MapView): Boolean {
        if (!isActive) return false
        val geoPoint = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt()) as GeoPoint
        points.add(geoPoint)
        onDistanceChanged(totalDistance(), points.size)
        mapView.invalidate()
        return true
    }

    // ── Oeffentliche API ──────────────────────────────────────────────────────

    /** Entfernt den zuletzt gesetzten Punkt. */
    fun undo() {
        if (points.isNotEmpty()) {
            points.removeAt(points.size - 1)
            onDistanceChanged(totalDistance(), points.size)
        }
    }

    /** Loescht alle Messpunkte. */
    fun clear() {
        points.clear()
        onDistanceChanged(0.0, 0)
    }

    /** Gesamtlaenge aller Segmente in Metern. */
    fun totalDistance(): Double =
        (1 until points.size).sumOf { haversine(points[it - 1], points[it]) }

    // ── Mathematik ────────────────────────────────────────────────────────────

    /**
     * Haversine-Distanz zwischen zwei GeoPoints in Metern.
     *
     * @param a  Startpunkt
     * @param b  Endpunkt
     * @return   Distanz in Metern
     */
    private fun haversine(a: GeoPoint, b: GeoPoint): Double {
        val R    = 6_371_000.0
        val dLat = Math.toRadians(b.latitude  - a.latitude)
        val dLon = Math.toRadians(b.longitude - a.longitude)
        val h    = sin(dLat / 2).pow(2) +
                   cos(Math.toRadians(a.latitude)) *
                   cos(Math.toRadians(b.latitude)) *
                   sin(dLon / 2).pow(2)
        return 2 * R * asin(sqrt(h))
    }

    companion object {
        /** Formatiert eine Distanz in Metern als lesbaren String. */
        fun formatDistance(meters: Double): String = when {
            meters >= 1_000_000 -> "%.2f Mm".format(meters / 1_000_000)
            meters >= 1_000     -> "%.3f km".format(meters / 1_000)
            else                -> "%.1f m".format(meters)
        }
    }
}
