package com.maptileviewer

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.osmdroid.views.MapView
import java.io.File
import java.io.FileOutputStream

/**
 * Exportiert den aktuellen Kartenausschnitt als PNG-Datei.
 *
 * Verwendet die moderne Canvas-API statt der veralteten DrawingCache-API.
 * Auf Android 10+ wird MediaStore verwendet (keine Speicher-Berechtigung noetig).
 * Auf aelteren Geraeten wird direkt in den Downloads-Ordner geschrieben.
 */
object ExportHelper {

    fun exportMapToPng(context: Context, mapView: MapView): String? {
        return try {
            // Moderne API: direkt auf Canvas zeichnen (kein deprecated DrawingCache)
            val bitmap = Bitmap.createBitmap(
                mapView.width, mapView.height, Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            mapView.draw(canvas)

            val fileName = "karte_${System.currentTimeMillis()}.png"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+: MediaStore (keine WRITE_EXTERNAL_STORAGE noetig)
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_PICTURES}/MapTileViewer")
                }
                val uri = context.contentResolver
                    .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                bitmap.recycle()
                uri.toString()
            } else {
                // Android 9 und aelter
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), "MapTileViewer")
                dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                bitmap.recycle()
                file.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
