package com.maptileviewer

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.osmdroid.views.MapView
import java.io.File
import java.io.FileOutputStream
import java.io.OutputStream

/**
 * Exportiert den aktuellen Kartenausschnitt als PNG-Datei.
 *
 * Auf Android 10+ wird der MediaStore-API verwendet (kein WRITE_EXTERNAL_STORAGE
 * Berechtigung noetig). Auf aelteren Geraeten wird direkt in den Downloads-Ordner
 * geschrieben.
 *
 * @param context  Anwendungs-Context.
 * @param mapView  Die zu exportierende MapView.
 * @return         Pfad/URI der gespeicherten Datei als String, oder null bei Fehler.
 */
object ExportHelper {

    fun exportMapToPng(context: Context, mapView: MapView): String? {
        return try {
            // Karte in Bitmap zeichnen
            mapView.isDrawingCacheEnabled = true
            val bitmap = Bitmap.createBitmap(mapView.drawingCache)
            mapView.isDrawingCacheEnabled = false

            val fileName = "karte_${System.currentTimeMillis()}.png"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+: MediaStore
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                    put(MediaStore.Images.Media.RELATIVE_PATH,
                        "${Environment.DIRECTORY_PICTURES}/MapTileViewer")
                }
                val uri = context.contentResolver
                    .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return null
                context.contentResolver.openOutputStream(uri)?.use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                uri.toString()
            } else {
                // Android 9 und aelter: direkter Dateizugriff
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES), "MapTileViewer")
                dir.mkdirs()
                val file = File(dir, fileName)
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                file.absolutePath
            }
        } catch (e: Exception) {
            null
        }
    }
}
