package com.maptileviewer

import android.graphics.*
import android.view.MotionEvent
import org.osmdroid.util.BoundingBox
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay

/**
 * Overlay zum Aufziehen eines Download-Rechtecks per Finger-Drag.
 * Erster Touch = Ecke A, Finger-Release = Ecke B -> liefert BoundingBox.
 */
class RegionSelectOverlay(
    private val onRegionSelected: (BoundingBox) -> Unit
) : Overlay() {

    private val paintFill   = Paint().apply {
        color = Color.argb(60, 33, 150, 243)
        style = Paint.Style.FILL
    }
    private val paintStroke = Paint().apply {
        color = Color.rgb(33, 150, 243)
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val paintLabel  = Paint().apply {
        color = Color.WHITE
        textSize = 36f
        isFakeBoldText = true
        setShadowLayer(4f, 0f, 0f, Color.BLACK)
    }

    private var startScreen: PointF? = null
    private var currentScreen: PointF? = null
    private var startGeo: GeoPoint? = null
    var active = false

    override fun onTouchEvent(e: MotionEvent, mapView: MapView): Boolean {
        if (!active) return false
        when (e.action) {
            MotionEvent.ACTION_DOWN -> {
                startScreen  = PointF(e.x, e.y)
                currentScreen = PointF(e.x, e.y)
                startGeo = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt()) as GeoPoint
            }
            MotionEvent.ACTION_MOVE -> {
                currentScreen = PointF(e.x, e.y)
                mapView.invalidate()
            }
            MotionEvent.ACTION_UP -> {
                val endGeo = mapView.projection.fromPixels(e.x.toInt(), e.y.toInt()) as GeoPoint
                val s = startGeo ?: return false
                val bbox = BoundingBox(
                    maxOf(s.latitude,  endGeo.latitude),
                    maxOf(s.longitude, endGeo.longitude),
                    minOf(s.latitude,  endGeo.latitude),
                    minOf(s.longitude, endGeo.longitude)
                )
                active = false
                startScreen  = null
                currentScreen = null
                mapView.invalidate()
                if (bbox.diagonalLengthInMeters > 100) onRegionSelected(bbox)
            }
        }
        return true
    }

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        val s = startScreen   ?: return
        val c = currentScreen ?: return
        val rect = RectF(
            minOf(s.x, c.x), minOf(s.y, c.y),
            maxOf(s.x, c.x), maxOf(s.y, c.y)
        )
        canvas.drawRect(rect, paintFill)
        canvas.drawRect(rect, paintStroke)
        canvas.drawText("Bereich auswählen", rect.left + 8f, rect.top - 12f, paintLabel)
    }
}
