package com.maptileviewer

import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.MapTileIndex

/**
 * Vordefinierte Kachelquellen fuer alle unterstuetzten Kartenanbieter.
 *
 * OsmDroid uebernimmt automatisch Disk-Caching, HTTP-Anfragen und
 * Fehlerbehandlung fuer alle hier registrierten Quellen.
 */
object TileSources {

    /** OpenStreetMap – Standard-Raster */
    val OSM: OnlineTileSourceBase = TileSourceFactory.MAPNIK

    /** Google Maps – Strassenkarte */
    val GOOGLE_STREET = object : OnlineTileSourceBase(
        "Google_Street", 0, 20, 256, ".png",
        arrayOf("https://mt0.google.com", "https://mt1.google.com",
                "https://mt2.google.com", "https://mt3.google.com")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val base = baseUrl[(x + y).toInt() and 3]
            return "$base/vt/lyrs=m&x=$x&y=$y&z=$z"
        }
    }

    /** Google Maps – Satellitenbild */
    val GOOGLE_SAT = object : OnlineTileSourceBase(
        "Google_Sat", 0, 20, 256, ".jpg",
        arrayOf("https://mt0.google.com", "https://mt1.google.com",
                "https://mt2.google.com", "https://mt3.google.com")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            val base = baseUrl[(x + y).toInt() and 3]
            return "$base/vt/lyrs=s&x=$x&y=$y&z=$z"
        }
    }

    /** Google Maps – Hybrid (Satellit + Beschriftung) */
    val GOOGLE_HYBRID = object : OnlineTileSourceBase(
        "Google_Hybrid", 0, 20, 256, ".jpg",
        arrayOf("https://mt0.google.com", "https://mt1.google.com")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            return "${baseUrl[0]}/vt/lyrs=y&x=$x&y=$y&z=$z"
        }
    }

    /** Bing Maps – Strassenkarte (Quadkey-Format) */
    val BING_STREET = object : OnlineTileSourceBase(
        "Bing_Street", 1, 19, 256, ".png",
        arrayOf("https://t0.ssl.ak.tiles.virtualearth.net")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val qk = toQuadKey(pMapTileIndex)
            return "https://t0.ssl.ak.tiles.virtualearth.net/tiles/r$qk.png?g=1"
        }
    }

    /** Bing Maps – Satellit (Quadkey-Format) */
    val BING_SAT = object : OnlineTileSourceBase(
        "Bing_Sat", 1, 19, 256, ".jpg",
        arrayOf("https://t0.ssl.ak.tiles.virtualearth.net")
    ) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val qk = toQuadKey(pMapTileIndex)
            return "https://t0.ssl.ak.tiles.virtualearth.net/tiles/a$qk.jpeg?g=1"
        }
    }

    /**
     * Kodiert einen OsmDroid-Kachel-Index als Bing-Quadkey-String.
     *
     * @param pMapTileIndex  Gepackter Tile-Index (Zoom/X/Y in einem Long)
     * @return Quadkey-String (z.B. "0213120")
     */
    private fun toQuadKey(pMapTileIndex: Long): String {
        val zoom = MapTileIndex.getZoom(pMapTileIndex)
        val x    = MapTileIndex.getX(pMapTileIndex)
        val y    = MapTileIndex.getY(pMapTileIndex)
        val sb   = StringBuilder()
        for (i in zoom downTo 1) {
            var digit = 0
            val mask  = 1 shl (i - 1)
            if ((x and mask) != 0) digit++
            if ((y and mask) != 0) digit += 2
            sb.append(digit)
        }
        return sb.toString()
    }

    /** Alle verfuegbaren Quellen als geordnete Map (Name -> Quelle). */
    val ALL = linkedMapOf(
        "OpenStreetMap"   to OSM,
        "Google Straße"   to GOOGLE_STREET,
        "Google Satellit" to GOOGLE_SAT,
        "Google Hybrid"   to GOOGLE_HYBRID,
        "Bing Straße"     to BING_STREET,
        "Bing Satellit"   to BING_SAT,
    )
}
