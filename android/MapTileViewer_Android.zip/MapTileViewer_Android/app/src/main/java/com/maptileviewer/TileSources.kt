package com.maptileviewer

import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.tileprovider.tilesource.XYTileSource
import org.osmdroid.util.MapTileIndex

object TileSources {

    private val PROXY = "http://${TileProxyServer.HOST}:${TileProxyServer.PORT}"

    // Google Maps via lokalen Proxy (setzt Referer + Browser-UA)
    val GOOGLE_STREET  = XYTileSource("Google_Street",  0, 20, 256, ".png",
        arrayOf("$PROXY/google_street/"))
    val GOOGLE_SAT     = XYTileSource("Google_Sat",     0, 20, 256, ".jpg",
        arrayOf("$PROXY/google_sat/"))
    val GOOGLE_HYBRID  = XYTileSource("Google_Hybrid",  0, 20, 256, ".jpg",
        arrayOf("$PROXY/google_hybrid/"))

    // Direkt-Anbieter (kein spezieller Header noetig)
    val CARTO_LIGHT = XYTileSource("CartoDB_Light", 0, 19, 256, ".png",
        arrayOf("https://a.basemaps.cartocdn.com/rastertiles/voyager/",
                "https://b.basemaps.cartocdn.com/rastertiles/voyager/",
                "https://c.basemaps.cartocdn.com/rastertiles/voyager/"))

    val CARTO_DARK = object : OnlineTileSourceBase("Esri_Dark", 0, 16, 256, ".png",
        arrayOf("https://server.arcgisonline.com")) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            return "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Dark_Gray_Base/MapServer/tile/$z/$y/$x"
        }
    }

    val OPEN_TOPO = XYTileSource("OpenTopoMap", 0, 17, 256, ".png",
        arrayOf("https://a.tile.opentopomap.org/",
                "https://b.tile.opentopomap.org/",
                "https://c.tile.opentopomap.org/"))

    val ESRI_STREET = object : OnlineTileSourceBase("Esri_Street", 0, 19, 256, ".jpg",
        arrayOf("https://server.arcgisonline.com")) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            return "https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/$z/$y/$x"
        }
    }

    val ESRI_SAT = object : OnlineTileSourceBase("Esri_Sat", 0, 19, 256, ".jpg",
        arrayOf("https://server.arcgisonline.com")) {
        override fun getTileURLString(pMapTileIndex: Long): String {
            val z = MapTileIndex.getZoom(pMapTileIndex)
            val x = MapTileIndex.getX(pMapTileIndex)
            val y = MapTileIndex.getY(pMapTileIndex)
            return "https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/$z/$y/$x"
        }
    }

    val BING_STREET = object : OnlineTileSourceBase("Bing_Street", 1, 19, 256, ".png",
        arrayOf("https://t0.ssl.ak.tiles.virtualearth.net")) {
        override fun getTileURLString(pMapTileIndex: Long): String =
            "https://t0.ssl.ak.tiles.virtualearth.net/tiles/r${toQuadKey(pMapTileIndex)}.png?g=1"
    }

    val BING_SAT = object : OnlineTileSourceBase("Bing_Sat", 1, 19, 256, ".jpg",
        arrayOf("https://t0.ssl.ak.tiles.virtualearth.net")) {
        override fun getTileURLString(pMapTileIndex: Long): String =
            "https://t0.ssl.ak.tiles.virtualearth.net/tiles/a${toQuadKey(pMapTileIndex)}.jpeg?g=1"
    }

    private fun toQuadKey(pMapTileIndex: Long): String {
        val zoom = MapTileIndex.getZoom(pMapTileIndex)
        val x    = MapTileIndex.getX(pMapTileIndex)
        val y    = MapTileIndex.getY(pMapTileIndex)
        val sb   = StringBuilder()
        for (i in zoom downTo 1) {
            var digit = 0
            val mask  = 1 shl (i - 1)
            if ((x and mask) != 0) digit++
            if ((y and mask) != 0) digit += 2
            sb.append(digit)
        }
        return sb.toString()
    }

    val ALL = linkedMapOf(
        "Google Strasse"  to GOOGLE_STREET,
        "Google Satellit" to GOOGLE_SAT,
        "Google Hybrid"   to GOOGLE_HYBRID,
        "CartoDB"         to CARTO_LIGHT,
        "Esri Dunkel"     to CARTO_DARK,
        "OpenTopoMap"     to OPEN_TOPO,
        "Esri Strasse"    to ESRI_STREET,
        "Esri Satellit"   to ESRI_SAT,
        "Bing Strasse"    to BING_STREET,
        "Bing Satellit"   to BING_SAT
    )
}
