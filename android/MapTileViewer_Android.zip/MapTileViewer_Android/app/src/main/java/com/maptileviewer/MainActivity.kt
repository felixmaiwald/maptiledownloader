package com.maptileviewer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.maptileviewer.databinding.ActivityMainBinding
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.overlay.compass.CompassOverlay
import org.osmdroid.views.overlay.ScaleBarOverlay

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var measureOverlay: MeasureOverlay
    private lateinit var locationManager: LocationManager
    private lateinit var locationOverlay: LocationOverlay

    private var locationJob: Job? = null
    private var followMode = false

    // ── Permission Launcher ───────────────────────────────────────────────────
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        val fine   = grants[Manifest.permission.ACCESS_FINE_LOCATION]   == true
        val coarse = grants[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        if (fine || coarse) {
            Toast.makeText(this, "GPS-Berechtigung erteilt", Toast.LENGTH_SHORT).show()
            startLocationUpdates()
        } else {
            Toast.makeText(this,
                "Standort nicht verfuegbar - Berechtigung verweigert",
                Toast.LENGTH_LONG).show()
        }
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Configuration.getInstance().userAgentValue = "MapTileViewer/2.0 (Android)"
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        locationManager = LocationManager(this)
        setupMap()
        setupProviderChips()
        setupMeasureTool()
        setupSearch()
        setupLocationButton()
        setupExportButton()
    }

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
        if (followMode) startLocationUpdates()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
        stopLocationUpdates()
    }

    // ── Karte ─────────────────────────────────────────────────────────────────
    private fun setupMap() {
        val map = binding.mapView
        map.setTileSource(TileSources.OSM)
        map.zoomController.setVisibility(
            CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
        map.setMultiTouchControls(true)
        map.controller.apply {
            setZoom(12.0)
            setCenter(GeoPoint(48.1374, 11.5755))
        }
        map.overlays.add(ScaleBarOverlay(map).apply { setCentred(false) })
        map.overlays.add(CompassOverlay(this, map).apply { enableCompass() })
        locationOverlay = LocationOverlay(map)
        map.overlays.add(locationOverlay)
    }

    // ── Kartenanbieter ────────────────────────────────────────────────────────
    private fun setupProviderChips() {
        TileSources.ALL.forEach { (name, source) ->
            val chip = Chip(this).apply {
                text        = name
                isCheckable = true
                isChecked   = (source == TileSources.OSM)
                setOnClickListener { switchProvider(source, this) }
            }
            binding.chipGroupProviders.addView(chip)
        }
    }

    private fun switchProvider(source: OnlineTileSourceBase, chip: Chip) {
        binding.mapView.setTileSource(source)
        repeat(binding.chipGroupProviders.childCount) { i ->
            (binding.chipGroupProviders.getChildAt(i) as? Chip)?.isChecked = false
        }
        chip.isChecked = true
        binding.mapView.invalidate()
    }

    // ── Messwerkzeug ──────────────────────────────────────────────────────────
    private fun setupMeasureTool() {
        measureOverlay = MeasureOverlay { totalMeters, count ->
            runOnUiThread {
                if (count == 0) {
                    binding.tvMeasureResult.visibility = View.GONE
                } else {
                    binding.tvMeasureResult.visibility = View.VISIBLE
                    binding.tvMeasureResult.text =
                        if (count < 2) "Punkt A gesetzt - weiteren Punkt tippen"
                        else "Gesamt: ${MeasureOverlay.formatDistance(totalMeters)}  ($count Punkte)"
                }
            }
        }
        binding.mapView.overlays.add(measureOverlay)

        binding.btnMeasure.setOnClickListener {
            measureOverlay.isActive = !measureOverlay.isActive
            binding.btnMeasure.text = if (measureOverlay.isActive) "Stop Messen" else "Messen"
        }
        binding.btnMeasureUndo.setOnClickListener {
            measureOverlay.undo()
            binding.mapView.invalidate()
        }
        binding.btnMeasureClear.setOnClickListener {
            measureOverlay.clear()
            measureOverlay.isActive = false
            binding.btnMeasure.text = "Messen"
            binding.mapView.invalidate()
        }
    }

    // ── Ortssuche ─────────────────────────────────────────────────────────────
    private fun setupSearch() {
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) { performSearch(); true } else false
        }
        binding.btnSearch.setOnClickListener { performSearch() }
    }

    private fun performSearch() {
        val query = binding.etSearch.text.toString().trim()
        if (query.isEmpty()) return
        hideKeyboard()
        binding.btnSearch.isEnabled = false
        lifecycleScope.launch {
            val result = GeocodingService.search(query)
            binding.btnSearch.isEnabled = true
            if (result != null) {
                if (followMode) toggleFollowMode()
                binding.mapView.controller.animateTo(result)
                binding.mapView.controller.setZoom(14.0)
            } else {
                Toast.makeText(this@MainActivity,
                    "Ort nicht gefunden: $query",
                    Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── GPS / Standort ────────────────────────────────────────────────────────
    private fun setupLocationButton() {
        binding.fabMyLocation.setOnClickListener {
            when {
                locationManager.hasPermission() -> {
                    if (!followMode) {
                        locationManager.getLastKnownLocation { loc ->
                            loc?.let {
                                runOnUiThread {
                                    val gp = GeoPoint(it.latitude, it.longitude)
                                    binding.mapView.controller.animateTo(gp)
                                    binding.mapView.controller.setZoom(16.0)
                                }
                            }
                        }
                    }
                    toggleFollowMode()
                }
                shouldShowRequestPermissionRationale(
                    Manifest.permission.ACCESS_FINE_LOCATION) -> showPermissionRationale()
                else -> requestLocationPermission()
            }
        }
        binding.fabMyLocation.setOnLongClickListener {
            showLocationInfoDialog()
            true
        }
    }

    private fun toggleFollowMode() {
        followMode = !followMode
        if (followMode) {
            startLocationUpdates()
            Toast.makeText(this, "GPS folgen: Ein", Toast.LENGTH_SHORT).show()
        } else {
            stopLocationUpdates()
            binding.tvGpsInfo.visibility = View.GONE
            Toast.makeText(this, "GPS folgen: Aus", Toast.LENGTH_SHORT).show()
        }
    }

    private fun startLocationUpdates() {
        if (!locationManager.hasPermission()) return
        locationJob?.cancel()
        locationJob = lifecycleScope.launch {
            locationManager.locationFlow()
                .catch { e ->
                    runOnUiThread {
                        Toast.makeText(this@MainActivity,
                            "GPS-Fehler: ${e.message}",
                            Toast.LENGTH_SHORT).show()
                    }
                }
                .collect { update ->
                    when (update) {
                        is LocationUpdate.Success     -> onLocationUpdate(update)
                        is LocationUpdate.Unavailable -> onLocationUnavailable()
                        is LocationUpdate.NoPermission -> requestLocationPermission()
                    }
                }
        }
    }

    private fun stopLocationUpdates() {
        locationJob?.cancel()
        locationJob = null
    }

    private fun onLocationUpdate(update: LocationUpdate.Success) {
        val loc = update.location
        val gp  = GeoPoint(loc.latitude, loc.longitude)
        locationOverlay.updateLocation(gp, loc.accuracy)
        binding.mapView.invalidate()

        binding.tvGpsInfo.visibility = View.VISIBLE
        val speedStr   = if (loc.hasSpeed())   "  ${(loc.speed * 3.6).toInt()} km/h" else ""
        val bearingStr = if (loc.hasBearing()) "  ${loc.bearing.toInt()} Grad"       else ""
        val lat  = "%+.5f".format(loc.latitude)
        val lon  = "%+.6f".format(loc.longitude)
        val acc  = locationManager.formatAccuracy(loc.accuracy)
        binding.tvGpsInfo.text = "$lat  $lon\n$acc$speedStr$bearingStr"

        if (followMode) {
            binding.mapView.controller.animateTo(gp)
        }
    }

    private fun onLocationUnavailable() {
        binding.tvGpsInfo.text = "GPS nicht verfuegbar ..."
        binding.tvGpsInfo.visibility = View.VISIBLE
    }

    // ── Dialoge ───────────────────────────────────────────────────────────────
    private fun showPermissionRationale() {
        val msg = "Der Map Tile Viewer benoetigt Ihren Standort, um die Karte auf " +
                  "Ihre aktuelle Position zu zentrieren.\n\n" +
                  "Die Standortdaten werden nur lokal zur Kartenanzeige verwendet."
        AlertDialog.Builder(this)
            .setTitle("Standort-Berechtigung benoetigt")
            .setMessage(msg)
            .setPositiveButton("Berechtigung erteilen") { _, _ -> requestLocationPermission() }
            .setNegativeButton("Abbrechen", null)
            .show()
    }

    private fun showLocationInfoDialog() {
        val modeStr = if (followMode) "Ein (Karte folgt GPS)" else "Aus"
        val permStr = if (locationManager.hasPermission()) "erteilt" else "fehlt"
        val msg = "Follow-Modus: $modeStr\nBerechtigung: $permStr\n\n" +
                  "Kurz tippen: Follow-Modus ein/aus\n" +
                  "Lang druecken: Dieser Dialog"
        AlertDialog.Builder(this)
            .setTitle("GPS-Status")
            .setMessage(msg)
            .setPositiveButton("OK", null)
            .show()
    }

    private fun requestLocationPermission() {
        permissionLauncher.launch(arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ))
    }

    // ── Export ────────────────────────────────────────────────────────────────
    private fun setupExportButton() {
        binding.fabExport.setOnClickListener {
            val path = ExportHelper.exportMapToPng(this, binding.mapView)
            val msg  = if (path != null) "Gespeichert: $path" else "Export fehlgeschlagen"
            Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
        }
    }

    // ── Hilfe ─────────────────────────────────────────────────────────────────
    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(binding.root.windowToken, 0)
    }
}
