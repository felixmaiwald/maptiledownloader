package com.maptileviewer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.chip.Chip
import com.maptileviewer.databinding.ActivityMainBinding
import kotlinx.coroutines.launch
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.OnlineTileSourceBase
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.CustomZoomButtonsController
import org.osmdroid.views.overlay.compass.CompassOverlay
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay
import org.osmdroid.views.overlay.ScaleBarOverlay

/**
 * Haupt-Activity des Map Tile Viewers.
 *
 * Verantwortlichkeiten:
 *   - OsmDroid-Karte initialisieren und konfigurieren
 *   - Kartenanbieter-Chips verwalten
 *   - Messwerkzeug (MeasureOverlay) steuern
 *   - Geocoding-Suche ausfuehren (via GeocodingService)
 *   - PNG-Export anstossen (via ExportHelper)
 *   - Berechtigungen fuer Standort und Speicher anfordern
 */
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var measureOverlay: MeasureOverlay
    private lateinit var locationOverlay: MyLocationNewOverlay

    private var currentProvider: OnlineTileSourceBase = TileSources.OSM

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // OsmDroid User-Agent konfigurieren (vor setContentView!)
        Configuration.getInstance().userAgentValue = "MapTileViewer/1.0 (Android)"

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupMap()
        setupProviderChips()
        setupMeasureTool()
        setupSearch()
        setupButtons()
        requestPermissions()
    }

    override fun onResume() {
        super.onResume()
        binding.mapView.onResume()
    }

    override fun onPause() {
        super.onPause()
        binding.mapView.onPause()
    }

    // ── Karte einrichten ──────────────────────────────────────────────────────

    /**
     * Initialisiert die OsmDroid-MapView mit Startposition, Zoom,
     * Gesten-Einstellungen und Standard-Overlays (Kompass, Massstab).
     */
    private fun setupMap() {
        val map = binding.mapView
        map.setTileSource(TileSources.OSM)
        map.zoomController.setVisibility(CustomZoomButtonsController.Visibility.SHOW_AND_FADEOUT)
        map.setMultiTouchControls(true)

        // Startposition: Muenchen
        map.controller.apply {
            setZoom(12.0)
            setCenter(GeoPoint(48.1374, 11.5755))
        }

        // Massstabsleiste
        val scaleBar = ScaleBarOverlay(map)
        scaleBar.setCentred(false)
        map.overlays.add(scaleBar)

        // Kompass
        val compass = CompassOverlay(this, map)
        compass.enableCompass()
        map.overlays.add(compass)

        // Eigener Standort
        locationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(this), map)
        map.overlays.add(locationOverlay)
    }

    // ── Anbieter-Chips ────────────────────────────────────────────────────────

    /**
     * Erstellt zur Laufzeit je einen Material-Chip pro Kartenanbieter
     * und verbindet ihn mit dem entsprechenden TileSource-Wechsel.
     */
    private fun setupProviderChips() {
        TileSources.ALL.forEach { (name, source) ->
            val chip = Chip(this).apply {
                text            = name
                isCheckable     = true
                isChecked       = (source == TileSources.OSM)
                setOnClickListener { switchProvider(source, this) }
            }
            binding.chipGroupProviders.addView(chip)
        }
    }

    private fun switchProvider(source: OnlineTileSourceBase, chip: Chip) {
        currentProvider = source
        binding.mapView.setTileSource(source)
        // Alle anderen Chips abwaehlen
        for (i in 0 until binding.chipGroupProviders.childCount) {
            (binding.chipGroupProviders.getChildAt(i) as? Chip)?.isChecked = false
        }
        chip.isChecked = true
        binding.mapView.invalidate()
    }

    // ── Messwerkzeug ──────────────────────────────────────────────────────────

    /**
     * Initialisiert MeasureOverlay und verbindet ihn mit den Toolbar-Buttons.
     * Der Distanz-Callback aktualisiert das TextView in der Bottom-Bar.
     */
    private fun setupMeasureTool() {
        measureOverlay = MeasureOverlay { totalMeters, count ->
            runOnUiThread {
                if (count == 0) {
                    binding.tvMeasureResult.visibility = View.GONE
                } else {
                    binding.tvMeasureResult.visibility = View.VISIBLE
                    val dist = MeasureOverlay.formatDistance(totalMeters)
                    binding.tvMeasureResult.text =
                        if (count < 2) "Punkt A gesetzt – weiteren Punkt tippen"
                        else "∑ $dist  ($count Punkte)"
                }
            }
        }
        binding.mapView.overlays.add(measureOverlay)

        binding.btnMeasure.setOnClickListener {
            measureOverlay.isActive = !measureOverlay.isActive
            binding.btnMeasure.text = if (measureOverlay.isActive) "⏹ Messen" else "📏 Messen"
            if (!measureOverlay.isActive) {
                binding.tvMeasureResult.visibility = View.GONE
            }
        }

        binding.btnMeasureUndo.setOnClickListener {
            measureOverlay.undo()
            binding.mapView.invalidate()
        }

        binding.btnMeasureClear.setOnClickListener {
            measureOverlay.clear()
            measureOverlay.isActive = false
            binding.btnMeasure.text = "📏 Messen"
            binding.mapView.invalidate()
        }
    }

    // ── Ortssuche ─────────────────────────────────────────────────────────────

    /**
     * Verbindet das Suchfeld mit GeocodingService.
     * Die Netzwerkanfrage laeuft im IO-Dispatcher via lifecycleScope.
     */
    private fun setupSearch() {
        binding.etSearch.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                performSearch()
                true
            } else false
        }
        binding.btnSearch.setOnClickListener { performSearch() }
    }

    private fun performSearch() {
        val query = binding.etSearch.text.toString().trim()
        if (query.isEmpty()) return
        binding.btnSearch.isEnabled = false

        lifecycleScope.launch {
            val result = GeocodingService.search(query)
            binding.btnSearch.isEnabled = true
            if (result != null) {
                binding.mapView.controller.animateTo(result)
                binding.mapView.controller.setZoom(14.0)
            } else {
                Toast.makeText(this@MainActivity,
                    "Ort nicht gefunden: $query", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── Weitere Buttons ───────────────────────────────────────────────────────

    private fun setupButtons() {
        // Mein Standort
        binding.fabMyLocation.setOnClickListener {
            if (ActivityCompat.checkSelfPermission(
                    this, Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
                locationOverlay.enableMyLocation()
                locationOverlay.enableFollowLocation()
            } else {
                requestPermissions()
            }
        }

        // Screenshot / Export
        binding.fabExport.setOnClickListener {
            val path = ExportHelper.exportMapToPng(this, binding.mapView)
            if (path != null) {
                Toast.makeText(this, "Gespeichert:\n$path", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Export fehlgeschlagen", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // ── Berechtigungen ────────────────────────────────────────────────────────

    private fun requestPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.WRITE_EXTERNAL_STORAGE
            ),
            1001
        )
    }
}
