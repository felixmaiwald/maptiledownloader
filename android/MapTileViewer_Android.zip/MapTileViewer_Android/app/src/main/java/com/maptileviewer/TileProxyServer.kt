package com.maptileviewer

import kotlinx.coroutines.*
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.TimeUnit

object TileProxyServer {

    const val PORT = 17832
    const val HOST = "127.0.0.1"

    private val googleHeaders = mapOf(
        "User-Agent" to
            "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
            "AppleWebKit/537.36 (KHTML, like Gecko) " +
            "Chrome/121.0.0.0 Mobile Safari/537.36",
        "Referer"    to "https://maps.google.com/",
        "Accept"     to "image/webp,image/apng,image/*,*/*;q=0.8"
    )

    private val okHttp = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private var serverJob: Job? = null

    fun start(scope: CoroutineScope) {
        if (serverJob?.isActive == true) return
        serverJob = scope.launch(Dispatchers.IO) {
            val server = ServerSocket(PORT, 50, InetAddress.getByName(HOST))
            while (isActive) {
                try { val client = server.accept(); launch { handle(client) } }
                catch (_: Exception) {}
            }
            server.close()
        }
    }

    private suspend fun handle(socket: Socket) = withContext(Dispatchers.IO) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
            val out    = socket.getOutputStream()
            val line   = reader.readLine() ?: return@withContext
            val parts  = line.split(" ")
            if (parts.size < 2) return@withContext
            val path = parts[1]

            val pair = resolve(path)
            if (pair == null) {
                out.write(("HTTP/1.1 404 Not Found\r\n" +
                    "Content-Length: 0\r\n\r\n").toByteArray())
                return@withContext
            }
            val (realUrl, headers) = pair

            val req = Request.Builder().url(realUrl)
                .apply { headers.forEach { (k, v) -> header(k, v) } }
                .build()
            val response = okHttp.newCall(req).execute()
            val bytes    = response.body?.bytes()

            if (response.isSuccessful && bytes != null) {
                out.write(("HTTP/1.1 200 OK\r\n" +
                    "Content-Type: image/png\r\n" +
                    "Content-Length: " + bytes.size + "\r\n" +
                    "Connection: close\r\n\r\n").toByteArray())
                out.write(bytes)
            } else {
                out.write(("HTTP/1.1 502 Bad Gateway\r\n" +
                    "Content-Length: 0\r\n\r\n").toByteArray())
            }
            out.flush()
        } catch (_: Exception) {
        } finally {
            socket.close()
        }
    }

    private fun resolve(path: String): Pair<String, Map<String, String>>? {
        val clean = path.trimStart('/').substringBefore('?')
        val segs  = clean.split('/')
        if (segs.size < 4) return null
        val source = segs[0]
        val z      = segs[1]
        val x      = segs[2]
        val y      = segs[3].substringBefore('.')
        val host   = ((x.toLongOrNull() ?: 0L) + (y.toLongOrNull() ?: 0L)).toInt() and 3
        val lyrs   = when (source) {
            "google_street" -> "m"
            "google_sat"    -> "s"
            "google_hybrid" -> "y"
            else -> return null
        }
        val url = "https://mt$host.google.com/vt/lyrs=$lyrs&hl=de&x=$x&y=$y&z=$z&s=Ga"
        return url to googleHeaders
    }
}
