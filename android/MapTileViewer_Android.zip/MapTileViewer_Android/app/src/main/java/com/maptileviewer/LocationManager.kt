package com.maptileviewer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Verwaltet GPS- und Netzwerk-Standortaktualisierungen via FusedLocationProviderClient.
 * Alle Methoden pruefen die Berechtigung explizit vor dem API-Aufruf.
 */
class LocationManager(private val context: Context) {

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    // hasPermission() wird direkt davor geprueft -> @SuppressLint gerechtfertigt
    @SuppressLint("MissingPermission")
    fun getLastKnownLocation(onResult: (Location?) -> Unit) {
        if (!hasPermission()) { onResult(null); return }
        fusedClient.lastLocation
            .addOnSuccessListener { onResult(it) }
            .addOnFailureListener { onResult(null) }
    }

    // hasPermission() wird direkt davor geprueft -> @SuppressLint gerechtfertigt
    @SuppressLint("MissingPermission")
    fun locationFlow(
        accuracy: Int    = Priority.PRIORITY_HIGH_ACCURACY,
        intervalMs: Long = 2_000L,
        minDistanceM: Float = 3f
    ): Flow<LocationUpdate> = callbackFlow {

        if (!hasPermission()) {
            trySend(LocationUpdate.NoPermission)
            close()
            return@callbackFlow
        }

        val request = LocationRequest.Builder(accuracy, intervalMs)
            .setMinUpdateDistanceMeters(minDistanceM)
            .setWaitForAccurateLocation(false)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc -> trySend(LocationUpdate.Success(loc)) }
            }
            override fun onLocationAvailability(avail: LocationAvailability) {
                if (!avail.isLocationAvailable) trySend(LocationUpdate.Unavailable)
            }
        }

        fusedClient.requestLocationUpdates(request, callback, Looper.getMainLooper())
        awaitClose { fusedClient.removeLocationUpdates(callback) }
    }

    fun formatAccuracy(accuracyM: Float): String = when {
        accuracyM <= 5f   -> "+/-${accuracyM.toInt()} m (GPS)"
        accuracyM <= 20f  -> "+/-${accuracyM.toInt()} m (gut)"
        accuracyM <= 100f -> "+/-${accuracyM.toInt()} m (mittel)"
        else              -> "+/-${accuracyM.toInt()} m (ungenau)"
    }
}

sealed class LocationUpdate {
    data class Success(val location: Location) : LocationUpdate()
    object Unavailable  : LocationUpdate()
    object NoPermission : LocationUpdate()
}
