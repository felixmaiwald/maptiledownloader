package com.maptileviewer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Verwaltet GPS- und Netzwerk-Standortaktualisierungen via
 * FusedLocationProviderClient (Google Play Services).
 *
 * Liefert Standort-Updates als Kotlin Flow. Der Flow ist kalt –
 * Updates starten erst beim Collect und stoppen automatisch,
 * wenn der Flow abgebrochen wird (kein Memory Leak).
 *
 * Genauigkeits-Stufen:
 *   HIGH_ACCURACY  → GPS + WLAN + Netz, beste Genauigkeit, höchster Akkuverbrauch
 *   BALANCED       → WLAN + Netz, ~100 m Genauigkeit
 *   LOW_POWER      → nur Netz, ~1 km Genauigkeit
 *
 * @param context  Anwendungs- oder Activity-Context.
 */
class LocationManager(private val context: Context) {

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)

    // ── Öffentliche API ───────────────────────────────────────────────────────

    /**
     * Prüft ob alle nötigen Berechtigungen erteilt sind.
     *
     * @return true wenn ACCESS_FINE_LOCATION oder ACCESS_COARSE_LOCATION vorhanden.
     */
    fun hasPermission(): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    /**
     * Gibt den zuletzt bekannten Standort zurück (einmalig, kein Callback).
     * Nützlich für schnellen Karten-Sprung beim App-Start.
     *
     * @param onResult  Callback mit Location oder null (kein bekannter Standort).
     */
    fun getLastKnownLocation(onResult: (Location?) -> Unit) {
        if (!hasPermission()) { onResult(null); return }
        fusedClient.lastLocation.addOnSuccessListener { onResult(it) }
                                .addOnFailureListener { onResult(null) }
    }

    /**
     * Kontinuierliche Standort-Updates als Flow.
     *
     * @param accuracy  Genauigkeitsstufe (Standard: HIGH_ACCURACY).
     * @param intervalMs  Gewünschtes Update-Intervall in ms (Standard: 2 s).
     * @param minDistanceM  Minimale Bewegung für ein Update in Metern (Standard: 3 m).
     * @return  Flow<LocationUpdate> – emittiert bei jedem neuen Standort.
     */
    fun locationFlow(
        accuracy: Int   = Priority.PRIORITY_HIGH_ACCURACY,
        intervalMs: Long = 2_000L,
        minDistanceM: Float = 3f
    ): Flow<LocationUpdate> = callbackFlow {

        if (!hasPermission()) {
            trySend(LocationUpdate.NoPermission)
            close()
            return@callbackFlow
        }

        val request = LocationRequest.Builder(accuracy, intervalMs)
            .setMinUpdateDistanceMeters(minDistanceM)
            .setWaitForAccurateLocation(false)
            .build()

        val callback = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                result.lastLocation?.let { loc ->
                    trySend(LocationUpdate.Success(loc))
                }
            }
            override fun onLocationAvailability(avail: LocationAvailability) {
                if (!avail.isLocationAvailable) {
                    trySend(LocationUpdate.Unavailable)
                }
            }
        }

        fusedClient.requestLocationUpdates(request, callback, Looper.getMainLooper())

        // Flow-Abbruch → Updates stoppen (kein Memory Leak)
        awaitClose { fusedClient.removeLocationUpdates(callback) }
    }

    /**
     * Gibt die menschenlesbare Genauigkeitsbeschreibung zurück.
     *
     * @param accuracyM  Genauigkeit in Metern (aus Location.accuracy).
     * @return  String wie "±5 m (GPS)" oder "±50 m (Netz)".
     */
    fun formatAccuracy(accuracyM: Float): String = when {
        accuracyM <= 5f   -> "±${accuracyM.toInt()} m  (GPS)"
        accuracyM <= 20f  -> "±${accuracyM.toInt()} m  (gut)"
        accuracyM <= 100f -> "±${accuracyM.toInt()} m  (mittel)"
        else              -> "±${accuracyM.toInt()} m  (ungenau)"
    }
}

// ── Sealed-Class für Flow-Updates ─────────────────────────────────────────────

/**
 * Typsicheres Ergebnis eines Standort-Updates.
 */
sealed class LocationUpdate {

    /**
     * Erfolgreicher Standort-Update.
     * @param location  Android-Location-Objekt mit lat/lon, Genauigkeit, Geschwindigkeit.
     */
    data class Success(val location: Location) : LocationUpdate()

    /** GPS/Netz-Provider nicht verfügbar (z. B. kein Signal in Gebäude). */
    object Unavailable : LocationUpdate()

    /** Fehlende Laufzeit-Berechtigung – App muss erneut anfragen. */
    object NoPermission : LocationUpdate()
}
