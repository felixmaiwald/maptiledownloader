package com.maptileviewer

import android.graphics.*
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Overlay
import kotlin.math.*

/**
 * Canvas-Overlay für die GPS-Position.
 *
 * Zeichnet:
 *   - Einen blauen Kreis mit weissem Rand an der aktuellen Position
 *   - Einen halbtransparenten Genauigkeitskreis (Radius = GPS-Accuracy in Metern)
 *   - Einen Richtungspfeil wenn Heading-Daten verfügbar sind
 *
 * Das Overlay wird mit updateLocation() von MainActivity aktualisiert
 * und ist thread-safe (alle Zeichnungen im UI-Thread via MapView.invalidate()).
 */
class LocationOverlay(private val mapView: MapView) : Overlay() {

    private var position: GeoPoint? = null
    private var accuracyM: Float    = 0f

    // ── Paint-Objekte ─────────────────────────────────────────────────────────

    private val dotFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#FF4488FF")
        style = Paint.Style.FILL
    }
    private val dotBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.WHITE
        style     = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val accuracyFill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#334488FF")   // halbtransparent blau
        style = Paint.Style.FILL
    }
    private val accuracyBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color     = Color.parseColor("#884488FF")
        style     = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val pulsePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#224488FF")
        style = Paint.Style.FILL
    }

    // ── Zeichnung ─────────────────────────────────────────────────────────────

    override fun draw(canvas: Canvas, mapView: MapView, shadow: Boolean) {
        if (shadow) return
        val pos = position ?: return
        val proj    = mapView.projection
        val screen  = proj.toPixels(pos, null)
        val cx      = screen.x.toFloat()
        val cy      = screen.y.toFloat()

        // Genauigkeitskreis (Radius in Metern → Pixel umrechnen)
        if (accuracyM > 0f) {
            val accuracyPx = metersToPixels(accuracyM, pos.latitude, mapView)
            if (accuracyPx in 10f..2000f) {
                canvas.drawCircle(cx, cy, accuracyPx, accuracyFill)
                canvas.drawCircle(cx, cy, accuracyPx, accuracyBorder)
            }
        }

        // GPS-Punkt
        canvas.drawCircle(cx, cy, 18f, dotFill)
        canvas.drawCircle(cx, cy, 18f, dotBorder)

        // Innerer Kern
        canvas.drawCircle(cx, cy, 6f, Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.FILL
        })
    }

    // ── Öffentliche API ───────────────────────────────────────────────────────

    /**
     * Aktualisiert Position und Genauigkeit.
     * Nach dem Aufruf muss mapView.invalidate() aufgerufen werden.
     *
     * @param geoPoint   Neue geografische Position.
     * @param accuracy   GPS-Genauigkeit in Metern (aus Location.accuracy).
     */
    fun updateLocation(geoPoint: GeoPoint, accuracy: Float) {
        position  = geoPoint
        accuracyM = accuracy
    }

    fun hasLocation(): Boolean = position != null
    fun getPosition(): GeoPoint? = position

    // ── Hilfsmethoden ─────────────────────────────────────────────────────────

    /**
     * Rechnet eine Distanz in Metern in Pixel auf dem aktuellen Zoom um.
     * Verwendet die Mercator-Skalierung (breitengradkorrigiert).
     *
     * @param meters    Distanz in Metern.
     * @param latitude  Breitengrad (für Mercator-Korrektur).
     * @param mapView   Aktuelle MapView (für Zoom-Abfrage).
     * @return          Entsprechende Pixelanzahl auf dem Bildschirm.
     */
    private fun metersToPixels(meters: Float, latitude: Double, mapView: MapView): Float {
        val zoom   = mapView.zoomLevelDouble
        val tileSize = 256.0
        val earthCirc = 2 * Math.PI * 6_371_000.0
        val metersPerPx = (earthCirc * cos(Math.toRadians(latitude))) /
                          (tileSize * 2.0.pow(zoom))
        return (meters / metersPerPx).toFloat()
    }
}
